# Financial Risks:
- There are always risks that threaten your financial stability. Losing your job, getting sued, not being able to work or pay off bills. Obviously reduce your risk, but having savings and make sure you have insurance.

- NOTE: Right now you don't know about insurance, but just think of it as something you opt into and pay for, and in return the insurance company helps you out financially during big troubles.

# Examples of risks:
- Some examples of risks that can affect your financial well-being.
1. Unemployment
2. Illness, injury, or disability.
3. Liability: Risk of being sued or held responsible for something that causees financial loss.
4. Property damage
5. Theft
6. Fraud
7. Identity theft

# Insurable and non-insurable risks:
- Some risks are insurable, meaning you can buy insurance to protect against financial loss. Such as home insurance. But other risks suc has inflation or market fluctuations aren't insurable.