# Long Term Care and Disability Insurance

- Disability Insurance: If you become disabled and can't work, then disability insurance will give you money to act as income for up to a certain amount. Typically about 50-70% of your salary until you can go back to work, or for a certain period of time.

- Long-term care insurance: Helps pay for care if you have a chronic illness, or disability that just makes it hard for you to take care of yourself. This includes paying for nursing home care, adult day care, and home health care.

- NOTE: Home health care is just hwen you can get health care services to your home, rather than going to a hospital or facility.

# Limitations of health insurrance support:
- Careful when relying on government-provided programs such as Medicare, or evening relying on your family to pay for these types of care. The governmnet provided programs have many conditions and may not even cover you. And your family may not have the capabilities to take care of you.

# Costs, benefits, and comparisons:
- Costs of these types of insurance can change based on various factors suc has age, overall health, and the coverage you want. A good thing is a lot of employers have disability insurance, allowing you to deduct some of your paycheck to get you in the insurance plan.

# Takeaway:
- For disability and long-term-care insurance, accidents, illnesses, and life happens to anyone. So this type of insurance gives you more preparation.